<?php

/**
 * @package Sifu Translations
*/

//$txt['sifu_translations_xxx'] = 'xxx';